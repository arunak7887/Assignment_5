package com.nimap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapTask2Application {

	public static void main(String[] args) {
		SpringApplication.run(NimapTask2Application.class, args);
	}

}
